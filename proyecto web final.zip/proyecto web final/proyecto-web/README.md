## Ayuda para realizar documentos de MarkDown (.md)

[MarkDown 101](https://support.discord.com/hc/en-us/articles/210298617-Markdown-Text-101-Chat-Formatting-Bold-Italic-Underline)

## Añadir aqui el registro de cambios:
-> marrquee, tabla, iframe multimedia, js
