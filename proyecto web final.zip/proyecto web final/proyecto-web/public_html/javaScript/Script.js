// Variables globales
let currentUser = null;
let clients = [];
let products = [];
let services = [];
let complaints = [];

// Inicialización del DOM
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    loadData();
    setupEventListeners();
    animateOnScroll();
});

// Inicialización de la aplicación
function initializeApp() {
    // Menú responsivo
    const menuToggle = document.getElementById('menu-toggle');
    const nav = document.getElementById('nav');
    
    if (menuToggle && nav) {
        menuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
        });
    }
    
    // Cerrar menú al hacer clic fuera
    document.addEventListener('click', function(e) {
        if (!nav.contains(e.target) && !menuToggle.contains(e.target)) {
            nav.classList.remove('active');
        }
    });
    
    // Scroll suave para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Cambiar header en scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.background = 'rgba(37, 99, 235, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.background = 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))';
            header.style.backdropFilter = 'none';
        }
    });
}

// Cargar datos iniciales
function loadData() {
    // Datos de ejemplo para clientes
    clients = [
        { id: 1, name: 'Juan Pérez', email: 'juan@email.com', phone: '999888777', service: 'Asesoramiento' },
        { id: 2, name: 'María García', email: 'maria@email.com', phone: '999888778', service: 'Inversiones' },
        { id: 3, name: 'Carlos López', email: 'carlos@email.com', phone: '999888779', service: 'Seguros' }
    ];
    
    // Datos de ejemplo para productos
    products = [
        { id: 1, name: 'Seguro de Vida', price: 150, category: 'Seguros', description: 'Protección integral para tu familia' },
        { id: 2, name: 'Préstamo Personal', price: 5000, category: 'Préstamos', description: 'Financiamiento flexible' },
        { id: 3, name: 'Inversión Plus', price: 1000, category: 'Inversiones', description: 'Rentabilidad garantizada' }
    ];
    
    // Datos de ejemplo para servicios
    services = [
        { id: 1, name: 'Asesoramiento Financiero', price: 200, duration: '1 hora', description: 'Consultoría personalizada' },
        { id: 2, name: 'Planificación de Inversiones', price: 300, duration: '2 horas', description: 'Estrategia de inversión' },
        { id: 3, name: 'Análisis de Riesgos', price: 250, duration: '1.5 horas', description: 'Evaluación completa' }
    ];
    
    // Datos de ejemplo para reclamos
    complaints = [
        { id: 1, client: 'Ana Rodríguez', type: 'Seguro', status: 'Pendiente', date: '2024-01-15' },
        { id: 2, client: 'Pedro Martínez', type: 'Préstamo', status: 'Resuelto', date: '2024-01-10' },
        { id: 3, client: 'Laura Sánchez', type: 'Inversión', status: 'En proceso', date: '2024-01-20' }
    ];
    
    updateDisplays();
}

// Configurar event listeners
function setupEventListeners() {
    // Formulario de consulta modal
    const consultaForm = document.getElementById('consultaForm');
    if (consultaForm) {
        consultaForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleConsultaForm();
        });
    }
    
    // Formularios de contacto
    const contactForms = document.querySelectorAll('.contact-form');
    contactForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleContactForm(this);
        });
    });
    
    // Calculadora de préstamos
    const loanCalculator = document.getElementById('loanCalculator');
    if (loanCalculator) {
        loanCalculator.addEventListener('submit', function(e) {
            e.preventDefault();
            calculateLoan();
        });
    }
    
    // Calculadora de inversiones
    const investmentCalculator = document.getElementById('investmentCalculator');
    if (investmentCalculator) {
        investmentCalculator.addEventListener('submit', function(e) {
            e.preventDefault();
            calculateInvestment();
        });
    }
}

// Funciones del Modal
function openModal() {
    const modal = document.getElementById('contactModal');
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal() {
    const modal = document.getElementById('contactModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Cerrar modal al hacer clic fuera
window.addEventListener('click', function(e) {
    const modal = document.getElementById('contactModal');
    if (e.target === modal) {
        closeModal();
    }
});

// Manejar formulario de consulta
function handleConsultaForm() {
    const form = document.getElementById('consultaForm');
    const formData = new FormData(form);
    
    // Simular envío
    showNotification('Consulta enviada exitosamente. Te contactaremos pronto.', 'success');
    form.reset();
    closeModal();
}

// Manejar formularios de contacto
function handleContactForm(form) {
    const formData = new FormData(form);
    
    // Validación básica
    const email = formData.get('email');
    const name = formData.get('name') || formData.get('nombre');
    
    if (!email || !name) {
        showNotification('Por favor completa todos los campos requeridos.', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showNotification('Por favor ingresa un email válido.', 'error');
        return;
    }
    
    // Simular envío
    showNotification('Mensaje enviado exitosamente. Te contactaremos pronto.', 'success');
    form.reset();
}

// Validar email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Mostrar notificaciones
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    // Agregar estilos si no existen
    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.innerHTML = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                padding: 15px 20px;
                border-radius: 10px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                z-index: 3000;
                animation: slideInRight 0.3s ease;
                max-width: 400px;
            }
            .notification-success { border-left: 4px solid var(--success-color); }
            .notification-error { border-left: 4px solid var(--error-color); }
            .notification-info { border-left: 4px solid var(--primary-color); }
            .notification-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .notification-close {
                background: none;
                border: none;
                cursor: pointer;
                margin-left: auto;
                color: var(--text-light);
            }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Auto-remove después de 5 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Calculadora básica (sidebar)
function calculate() {
    const amount = parseFloat(document.getElementById('amount').value);
    const rate = parseFloat(document.getElementById('rate').value);
    const time = parseFloat(document.getElementById('time').value);
    
    if (isNaN(amount) || isNaN(rate) || isNaN(time)) {
        document.getElementById('result').innerHTML = 'Por favor ingresa valores válidos';
        return;
    }
    
    const interest = (amount * rate * time) / 100;
    const total = amount + interest;
    
    document.getElementById('result').innerHTML = `
        <strong>Interés:</strong> S/ ${interest.toFixed(2)}<br>
        <strong>Total:</strong> S/ ${total.toFixed(2)}
    `;
}

// Calculadora de préstamos
function calculateLoan() {
    const amount = parseFloat(document.getElementById('loanAmount').value);
    const rate = parseFloat(document.getElementById('loanRate').value) / 100 / 12;
    const months = parseInt(document.getElementById('loanMonths').value);
    
    if (isNaN(amount) || isNaN(rate) || isNaN(months)) {
        showNotification('Por favor ingresa valores válidos', 'error');
        return;
    }
    
    const monthlyPayment = (amount * rate * Math.pow(1 + rate, months)) / (Math.pow(1 + rate, months) - 1);
    const totalPayment = monthlyPayment * months;
    const totalInterest = totalPayment - amount;
    
    document.getElementById('loanResult').innerHTML = `
        <div class="calculation-result">
            <h3>Resultado del Préstamo</h3>
            <p><strong>Cuota mensual:</strong> S/ ${monthlyPayment.toFixed(2)}</p>
            <p><strong>Total a pagar:</strong> S/ ${totalPayment.toFixed(2)}</p>
            <p><strong>Total de intereses:</strong> S/ ${totalInterest.toFixed(2)}</p>
        </div>
    `;
}

// Calculadora de inversiones
function calculateInvestment() {
    const initial = parseFloat(document.getElementById('initialAmount').value);
    const monthly = parseFloat(document.getElementById('monthlyAmount').value);
    const rate = parseFloat(document.getElementById('investmentRate').value) / 100 / 12;
    const years = parseInt(document.getElementById('investmentYears').value);
    const months = years * 12;
    
    if (isNaN(initial) || isNaN(monthly) || isNaN(rate) || isNaN(years)) {
        showNotification('Por favor ingresa valores válidos', 'error');
        return;
    }
    
    const futureValue = initial * Math.pow(1 + rate, months) + 
                       monthly * (Math.pow(1 + rate, months) - 1) / rate;
    const totalInvested = initial + (monthly * months);
    const totalReturn = futureValue - totalInvested;
    
    document.getElementById('investmentResult').innerHTML = `
        <div class="calculation-result">
            <h3>Resultado de la Inversión</h3>
            <p><strong>Valor futuro:</strong> S/ ${futureValue.toFixed(2)}</p>
            <p><strong>Total invertido:</strong> S/ ${totalInvested.toFixed(2)}</p>
            <p><strong>Ganancia:</strong> S/ ${totalReturn.toFixed(2)}</p>
            <p><strong>Rendimiento:</strong> ${((totalReturn / totalInvested) * 100).toFixed(2)}%</p>
        </div>
    `;
}

// Animaciones al hacer scroll
function animateOnScroll() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    });
    
    document.querySelectorAll('.service-card, .blog-card, .feature-card').forEach(el => {
        observer.observe(el);
    });
}

// CRUD para clientes
function addClient(clientData) {
    const newClient = {
        id: clients.length + 1,
        ...clientData,
        createdAt: new Date().toISOString()
    };
    clients.push(newClient);
    updateDisplays();
    showNotification('Cliente agregado exitosamente', 'success');
    return newClient;
}

function getClients() {
    return clients;
}

function updateClient(id, clientData) {
    const index = clients.findIndex(client => client.id === id);
    if (index !== -1) {
        clients[index] = { ...clients[index], ...clientData };
        updateDisplays();
        showNotification('Cliente actualizado exitosamente', 'success');
        return clients[index];
    }
    return null;
}

function deleteClient(id) {
    const index = clients.findIndex(client => client.id === id);
    if (index !== -1) {
        clients.splice(index, 1);
        updateDisplays();
        showNotification('Cliente eliminado exitosamente', 'success');
        return true;
    }
    return false;
}

function searchClients(query) {
    return clients.filter(client => 
        client.name.toLowerCase().includes(query.toLowerCase()) ||
        client.email.toLowerCase().includes(query.toLowerCase())
    );
}

// CRUD para productos
function addProduct(productData) {
    const newProduct = {
        id: products.length + 1,
        ...productData,
        createdAt: new Date().toISOString()
    };
    products.push(newProduct);
    updateDisplays();
    showNotification('Producto agregado exitosamente', 'success');
    return newProduct;
}

function getProducts() {
    return products;
}

function updateProduct(id, productData) {
    const index = products.findIndex(product => product.id === id);
    if (index !== -1) {
        products[index] = { ...products[index], ...productData };
        updateDisplays();
        showNotification('Producto actualizado exitosamente', 'success');
        return products[index];
    }
    return null;
}

function deleteProduct(id) {
    const index = products.findIndex(product => product.id === id);
    if (index !== -1) {
        products.splice(index, 1);
        updateDisplays();
        showNotification('Producto eliminado exitosamente', 'success');
        return true;
    }
    return false;
}

function searchProducts(query) {
    return products.filter(product => 
        product.name.toLowerCase().includes(query.toLowerCase()) ||
        product.category.toLowerCase().includes(query.toLowerCase())
    );
}

// CRUD para servicios
function addService(serviceData) {
    const newService = {
        id: services.length + 1,
        ...serviceData,
        createdAt: new Date().toISOString()
    };
    services.push(newService);
    updateDisplays();
    showNotification('Servicio agregado exitosamente', 'success');
    return newService;
}

function getServices() {
    return services;
}

function updateService(id, serviceData) {
    const index = services.findIndex(service => service.id === id);
    if (index !== -1) {
        services[index] = { ...services[index], ...serviceData };
        updateDisplays();
        showNotification('Servicio actualizado exitosamente', 'success');
        return services[index];
    }
    return null;
}

function deleteService(id) {
    const index = services.findIndex(service => service.id === id);
    if (index !== -1) {
        services.splice(index, 1);
        updateDisplays();
        showNotification('Servicio eliminado exitosamente', 'success');
        return true;
    }
    return false;
}

function searchServices(query) {
    return services.filter(service => 
        service.name.toLowerCase().includes(query.toLowerCase()) ||
        service.description.toLowerCase().includes(query.toLowerCase())
    );
}

// CRUD para reclamos
function addComplaint(complaintData) {
    const newComplaint = {
        id: complaints.length + 1,
        ...complaintData,
        status: 'Pendiente',
        date: new Date().toISOString().split('T')[0]
    };
    complaints.push(newComplaint);
    updateDisplays();
    showNotification('Reclamo registrado exitosamente', 'success');
    return newComplaint;
}

function getComplaints() {
    return complaints;
}

function updateComplaint(id, complaintData) {
    const index = complaints.findIndex(complaint => complaint.id === id);
    if (index !== -1) {
        complaints[index] = { ...complaints[index], ...complaintData };
        updateDisplays();
        showNotification('Reclamo actualizado exitosamente', 'success');
        return complaints[index];
    }
    return null;
}

function deleteComplaint(id) {
    const index = complaints.findIndex(complaint => complaint.id === id);
    if (index !== -1) {
        complaints.splice(index, 1);
        updateDisplays();
        showNotification('Reclamo eliminado exitosamente', 'success');
        return true;
    }
    return false;
}

function searchComplaints(query) {
    return complaints.filter(complaint => 
        complaint.client.toLowerCase().includes(query.toLowerCase()) ||
        complaint.type.toLowerCase().includes(query.toLowerCase())
    );
}

// Actualizar displays
function updateDisplays() {
    updateClientsTable();
    updateProductsTable();
    updateServicesTable();
    updateComplaintsTable();
}

// Actualizar tabla de clientes
function updateClientsTable() {
    const table = document.getElementById('clientsTable');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = '';
    
    clients.forEach(client => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.id}</td>
            <td>${client.name}</td>
            <td>${client.email}</td>
            <td>${client.phone}</td>
            <td>${client.service}</td>
            <td>
                <button onclick="editClient(${client.id})" class="btn btn-sm btn-primary">Editar</button>
                <button onclick="deleteClient(${client.id})" class="btn btn-sm btn-danger">Eliminar</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Actualizar tabla de productos
function updateProductsTable() {
    const table = document.getElementById('productsTable');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = '';
    
    products.forEach(product => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${product.category}</td>
            <td>S/ ${product.price}</td>
            <td>${product.description}</td>
            <td>
                <button onclick="editProduct(${product.id})" class="btn btn-sm btn-primary">Editar</button>
                <button onclick="deleteProduct(${product.id})" class="btn btn-sm btn-danger">Eliminar</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Actualizar tabla de servicios
function updateServicesTable() {
    const table = document.getElementById('servicesTable');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = '';
    
    services.forEach(service => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${service.id}</td>
            <td>${service.name}</td>
            <td>S/ ${service.price}</td>
            <td>${service.duration}</td>
            <td>${service.description}</td>
            <td>
                <button onclick="editService(${service.id})" class="btn btn-sm btn-primary">Editar</button>
                <button onclick="deleteService(${service.id})" class="btn btn-sm btn-danger">Eliminar</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Actualizar tabla de reclamos
function updateComplaintsTable() {
    const table = document.getElementById('complaintsTable');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = '';
    
    complaints.forEach(complaint => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${complaint.id}</td>
            <td>${complaint.client}</td>
            <td>${complaint.type}</td>
            <td><span class="status status-${complaint.status.toLowerCase()}">${complaint.status}</span></td>
            <td>${complaint.date}</td>
            <td>
                <button onclick="editComplaint(${complaint.id})" class="btn btn-sm btn-primary">Editar</button>
                <button onclick="deleteComplaint(${complaint.id})" class="btn btn-sm btn-danger">Eliminar</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Funciones de edición
function editClient(id) {
    const client = clients.find(c => c.id === id);
    if (client) {
        const newName = prompt('Nombre:', client.name);
        const newEmail = prompt('Email:', client.email);
        const newPhone = prompt('Teléfono:', client.phone);
        const newService = prompt('Servicio:', client.service);
        
        if (newName && newEmail && newPhone && newService) {
            updateClient(id, {
                name: newName,
                email: newEmail,
                phone: newPhone,
                service: newService
            });
        }
    }
}

function editProduct(id) {
    const product = products.find(p => p.id === id);
    if (product) {
        const newName = prompt('Nombre:', product.name);
        const newPrice = prompt('Precio:', product.price);
        const newCategory = prompt('Categoría:', product.category);
        const newDescription = prompt('Descripción:', product.description);
        
        if (newName && newPrice && newCategory && newDescription) {
            updateProduct(id, {
                name: newName,
                price: parseFloat(newPrice),
                category: newCategory,
                description: newDescription
            });
        }
    }
}

function editService(id) {
    const service = services.find(s => s.id === id);
    if (service) {
        const newName = prompt('Nombre:', service.name);
        const newPrice = prompt('Precio:', service.price);
        const newDuration = prompt('Duración:', service.duration);
        const newDescription = prompt('Descripción:', service.description);
        
        if (newName && newPrice && newDuration && newDescription) {
            updateService(id, {
                name: newName,
                price: parseFloat(newPrice),
                duration: newDuration,
                description: newDescription
            });
        }
    }
}

function editComplaint(id) {
    const complaint = complaints.find(c => c.id === id);
    if (complaint) {
        const newStatus = prompt('Estado (Pendiente/En proceso/Resuelto):', complaint.status);
        
        if (newStatus) {
            updateComplaint(id, { status: newStatus });
        }
    }
}

// Funciones para buscar
function searchInTable(tableId, query) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if (text.includes(query.toLowerCase())) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Funciones auxiliares
function formatCurrency(amount) {
    return `S/ ${amount.toFixed(2)}`;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-PE');
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Validaciones
function validateForm(formData) {
    const errors = [];
    
    if (!formData.name || formData.name.length < 2) {
        errors.push('El nombre debe tener al menos 2 caracteres');
    }
    
    if (!formData.email || !isValidEmail(formData.email)) {
        errors.push('Email inválido');
    }
    
    if (!formData.phone || formData.phone.length < 9) {
        errors.push('El teléfono debe tener al menos 9 dígitos');
    }
    
    return errors;
}

// Funciones para multimedia
function playVideo(videoId) {
    const video = document.getElementById(videoId);
    if (video) {
        video.play();
    }
}

function pauseVideo(videoId) {
    const video = document.getElementById(videoId);
    if (video) {
        video.pause();
    }
}

function playAudio(audioId) {
    const audio = document.getElementById(audioId);
    if (audio) {
        audio.play();
    }
}

function pauseAudio(audioId) {
    const audio = document.getElementById(audioId);
    if (audio) {
        audio.pause();
    }
}

// Funciones para comparativas
function compareProducts(product1Id, product2Id) {
    const product1 = products.find(p => p.id === product1Id);
    const product2 = products.find(p => p.id === product2Id);
    
    if (product1 && product2) {
        return {
            product1,
            product2,
            comparison: {
                priceDifference: Math.abs(product1.price - product2.price),
                cheaperProduct: product1.price < product2.price ? product1 : product2
            }
        };
    }
    return null;
}

// Funciones para reportes
function generateReport(type) {
    let data = [];
    let title = '';
    
    switch(type) {
        case 'clients':
            data = clients;
            title = 'Reporte de Clientes';
            break;
        case 'products':
            data = products;
            title = 'Reporte de Productos';
            break;
        case 'services':
            data = services;
            title = 'Reporte de Servicios';
            break;
        case 'complaints':
            data = complaints;
            title = 'Reporte de Reclamos';
            break;
    }
    
    const report = {
        title,
        generatedAt: new Date().toISOString(),
        data,
        summary: {
            total: data.length,
            lastUpdated: new Date().toLocaleDateString('es-PE')
        }
    };
    
    return report;
}

// Funciones para exportar datos
function exportToCSV(data, filename) {
    const csvContent = "data:text/csv;charset=utf-8," + 
        Object.keys(data[0]).join(",") + "\n" +
        data.map(row => Object.values(row).join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Funciones para imprimir
function printReport(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Reporte</title>');
        printWindow.document.write('<link rel="stylesheet" href="styles/index.css">');
        printWindow.document.write('</head><body>');
        printWindow.document.write(element.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }
}

// Funciones para dark mode
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDark);
}

// Cargar preferencia de dark mode
function loadDarkModePreference() {
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) {
        document.body.classList.add('dark-mode');
    }
}

// Funciones para cookies (simulación)
function setCookie(name, value, days) {
    const expires = new Date();
    expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
    document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

// Funciones para local storage simulado (usando variables)
const mockStorage = {
    data: {},
    setItem: function(key, value) {
        this.data[key] = value;
    },
    getItem: function(key) {
        return this.data[key] || null;
    },
    removeItem: function(key) {
        delete this.data[key];
    }
};

// Funciones para manejo de errores
function handleError(error, context) {
    console.error(`Error en ${context}:`, error);
    showNotification(`Error: ${error.message}`, 'error');
}

// Funciones para logging
function log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${type.toUpperCase()}: ${message}`);
}

// Inicializar cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    loadDarkModePreference();
    log('Aplicación inicializada correctamente');
});