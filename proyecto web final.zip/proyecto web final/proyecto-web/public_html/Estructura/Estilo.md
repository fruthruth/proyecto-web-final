#### **1. Esquema de Colores**  
Define los valores base para garantizar coherencia visual:

- **Fondo**: Blanco o gris claro (ej: `#F5F5F5`).
- **Texto**: Negro (`#222`) o gris oscuro para legibilidad.
- **Botones/CTA**: Naranja brillante (`#FF6600`) como color de llamada a la acción.
- **Enlaces y menú**: Texto blanco en fondo negro, con sombra suave.

---

#### **2. Estilo del Logo**  
Controla el diseño del logo en el menú:

```css
.logo-menu {
    margin-left: auto; /* Alineación derecha */
}
```

- **`logo-img-menu`**: Define la altura (`30px`) y proporción de la imagen.

---

#### **3. Menú**  
Estilo para la navegación principal:

```css
.menu {
    list-style: none;
    display: flex;
    background-color: #1A1A1A; /* Negro muy oscuro */
    padding: 0;
    margin: 0;
}
```

- **`menu li`**: Elementos del menú con margen derecho.
- **`menu a`**: Texto blanco, sin subrayado, con padding para espaciado.
- **`.submenu`**: Submenú oculto por defecto (`display: none`) y posicionado abajo del menú principal.  
  - **`submenu li a`**: Opciones de submenú con texto blanco y bordes redondeados.
  - **`submenu li:hover a`**: Cambio de fondo al pasar el mouse (gris medio).
- **`.categoria`**: Categorías dentro del submenú, con fuente en negrita y color gris claro (`#888`).

---

#### **4. Sección de Bienvenida (`hero`)**  
Estilo para la sección destacada:

```css
.hero {
    background-color: #F5F5F5; /* Fondo suave */
    padding: 40px 20px;
    text-align: center;
    color: #222222; /* Texto oscuro */
}
```

- **`btn-primary`**: Botones principales en naranja brillante, con efecto de transición al pasar el mouse.

---

#### **5. Sección de Servicios (`servicios`, `grid-servicios`, `servicio`)**  
Estilo para la cuadrícula de servicios:

```css
.servicios {
    padding: 40px 20px;
    max-width: 1200px;
    margin: auto;
}
```

- **`.grid-servicios`**: Cuadrícula responsive con elementos que se ajustan a la pantalla (`repeat(auto-fit, minmax(250px, 1fr))`).
- **`.servicio`**: Tarjetas de servicios con fondo blanco, sombra y efecto de hover.
- **`.btn-secundario`**: Botones secundarios en naranja claro, con efectos al pasar el mouse.

---

#### **6. Sección de Asesoramiento**  
Estilo para la sección de asesoría:

```css
.asesoramiento {
    background-color: #F5F5F5; /* Fondo suave */
    text-align: center;
}
```

- **Texto centralizado y color medio oscuro (`#333`)**.

---

#### **7. Testimonios**  
Estilo para los testimonios de clientes:

```css
.testimonios {
    background-color: #FFFFFF; /* Fondo blanco */
    text-align: center;
}
```

- **`.testimonial`**: Tarjetas con sombra, texto gris oscuro y efecto de hover.
- **`.testimonial em`**: Nombre del cliente destacado en naranja suave (`#2E7D32`).

---

#### **8. Pie de Página (`footer`, `subfooter`)**  
Estilo para el pie de página:

```css
.footer {
    background-color: #1A1A1A; /* Negro oscuro */
    color: white; /* Texto blanco */
}
```

- **`.footer-column`**: Columnas con contenido, ajustadas a pantallas pequeñas.
- **`.social-icons`**: Íconos de redes sociales con efecto al pasar el mouse.
- **`.subfooter`**: Información adicional en texto gris claro (`#888`) y bordes.

---

#### **9. Formularios**  
Estilo para formularios:

```css
form {
    display: flex;
    gap: 15px;
}
```

- **Campos de entrada**: Fondo blanco, borde gris medio y sombra al enfocar.
- **Botón de envío**: Naranja brillante con efecto de hover.

---

#### **10. Elementos Adicionales**  
- **`marquee`**: Texto en movimiento con fondo suave y color naranja.
- **`table`**: Tablas con bordes, encabezados en naranja y texto gris oscuro.
- **`iframe`**: Marco de contenido con borde redondeado y sombra.

---

#### **11. Responsividad**  
Ajuste para pantallas pequeñas:

```css
@media (max-width: 480px) {
    /* Alineación de botones, ajuste de imágenes */
}
```

- **Menú**: Cambia a diseño vertical en dispositivos móviles.
- **Imágenes y formularios**: Se adaptan al tamaño de la pantalla.

---